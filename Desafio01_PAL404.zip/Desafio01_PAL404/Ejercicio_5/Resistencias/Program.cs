﻿using System;

namespace Resistencias
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WindowHeight = 40;
            Console.WindowWidth = 70;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Clear();
            Console.Title = "Programa que calcula la resistencia";
            Console.Write("\n\n");
            //Declaracion de Variables
            double ba1, ba2, ba3, ba4;
            string con;
            double res, res2;
            Boolean bucle = true;
            //Entrada de Datos
            do
            {
                Console.Clear();
                Console.WriteLine("\tIngrese el número del color de cada una de la bandas: ");
                Console.WriteLine("\t0- Negro");
                Console.WriteLine("\t1- Marrón");
                Console.WriteLine("\t2- Rojo");
                Console.WriteLine("\t3- Naranja");
                Console.WriteLine("\t4- Amarillo");
                Console.WriteLine("\t5- Verde");
                Console.WriteLine("\t6- Azul");
                Console.WriteLine("\t7- Violeta");
                Console.WriteLine("\t8- Gris");
                Console.WriteLine("\t9- Blanco");
                Console.WriteLine("\tNúmeros solo válidos para la tercera y cuarta banda.");
                Console.WriteLine("\t10- Dorado");
                Console.WriteLine("\t11- Plateado");
                Console.WriteLine("\tNúmero solo válido para la cuarta banda.");
                Console.WriteLine("\t12- Sin banda");
                Console.WriteLine("\n");
                Console.WriteLine("\t13- Salir del Programa");
                Console.WriteLine("\n\n");
                Console.WriteLine("\tIngrese el color de la primera banda: ");
                ba1 = double.Parse(Console.ReadLine());
                Console.WriteLine("\n");
                Console.WriteLine("\tIngrese el color de la segunda banda: ");
                ba2 = double.Parse(Console.ReadLine());
                Console.WriteLine("\n");
                Console.WriteLine("\tIngrese el color de la tercera banda: ");
                ba3 = double.Parse(Console.ReadLine());
                Console.WriteLine("\n");
                Console.WriteLine("\tIngrese el color de la cuarta banda: ");
                Console.WriteLine("\t1- Marrón");
                Console.WriteLine("\t2- Rojo");
                Console.WriteLine("\t10- Dorado");
                Console.WriteLine("\t11- Plateado");
                Console.WriteLine("\t12 - Sin banda");
                ba4 = double.Parse(Console.ReadLine());
                Console.WriteLine("\n");

                switch (ba3)
                {
                    case 0:
                        con = ba1.ToString() + ba2.ToString();
                        res = double.Parse(con) * 1;
                        Console.WriteLine("\tLa resistencia es de: " + res + " Ohms.");
                        break;
                    case 1:
                        con = ba1.ToString() + ba2.ToString();
                        res = double.Parse(con) * 10;
                        Console.WriteLine("\tLa resistencia es de: " + res + " Ohms.");
                        break;
                    case 2:
                        con = ba1.ToString() + ba2.ToString();
                        res = double.Parse(con) * 100;
                        res2 = res / 1000;
                        Console.WriteLine("\tLa resistencia es de: " + res2 + " K Ohms.");
                        break;
                    case 3:
                        con = ba1.ToString() + ba2.ToString();
                        res = double.Parse(con) * 1000;
                        res2 = res / 1000;
                        Console.WriteLine("\tLa resistencia es de: " + res2 + " K Ohms.");
                        break;
                    case 4:
                        con = ba1.ToString() + ba2.ToString();
                        res = double.Parse(con) * 10000;
                        res2 = res / 1000;
                        Console.WriteLine("\tLa resistencia es de: " + res2 + " K Ohms.");
                        break;
                    case 5:
                        con = ba1.ToString() + ba2.ToString();
                        res = double.Parse(con) * 100000;
                        res2 = res / 1000000;
                        Console.WriteLine("\tLa resistencia es de: " + res2 + " M Ohms.");
                        break;
                    case 6:
                        con = ba1.ToString() + ba2.ToString();
                        res = double.Parse(con) * 1000000;
                        res2 = res / 1000000;
                        Console.WriteLine("\tLa resistencia es de: " + res2 + " M Ohms.");
                        break;
                    case 7:
                        con = ba1.ToString() + ba2.ToString();
                        res = double.Parse(con) * 10000000;
                        res2 = res / 1000000;
                        Console.WriteLine("\tLa resistencia es de: " + res2 + " M Ohms.");
                        break;
                    case 8:
                        con = ba1.ToString() + ba2.ToString();
                        res = double.Parse(con) * 100000000;
                        res2 = res / 1000000000;
                        Console.WriteLine("\tLa resistencia es de: " + res2 + " G Ohms.");
                        break;
                    case 9:
                        con = ba1.ToString() + ba2.ToString();
                        res = double.Parse(con) * 1000000000;
                        res2 = res / 1000000000;
                        Console.WriteLine("\tLa resistencia es de: " + res2 + " G Ohms.");
                        break;
                    default:
                        Console.WriteLine("Ingrese un número válido");
                        Console.WriteLine("\tPresiona cualquier tecla para reiniciar el programa...");
                        Console.ReadKey();
                        break;
                }
                if (ba3 == 10)
                {
                    con = ba1.ToString() + ba2.ToString();
                    res = double.Parse(con) * 0.1;
                    Console.WriteLine("\tLa resistencia es de: " + Math.Round(res, 2) + " Ohms.");
                }
                else if (ba3 == 11)
                {
                    con = ba1.ToString() + ba2.ToString();
                    res = double.Parse(con) * 0.01;
                    Console.WriteLine("\tLa resistencia es de: " + Math.Round(res, 2) + " Ohms.");
                }
                else if (ba3 == 13)
                {
                    bucle = false;
                }
                if (ba4 == 1)
                {
                    Console.WriteLine("\tLa resistencia posee un 1% de Tolerancia");
                    Console.WriteLine("\tPresiona cualquier tecla para reiniciar el programa...");
                    Console.ReadKey();
                }
                else if (ba4 == 2)
                {
                    Console.WriteLine("\tLa resistencia posee un 2% de Tolerancia");
                    Console.WriteLine("\tPresiona cualquier tecla para reiniciar el programa...");
                    Console.ReadKey();
                }
                else if (ba4 == 10)
                {
                    Console.WriteLine("\tLa resistencia posee un 5% de Tolerancia");
                    Console.WriteLine("\tPresiona cualquier tecla para reiniciar el programa...");
                    Console.ReadKey();
                }
                else if (ba4 == 11)
                {
                    Console.WriteLine("\tLa resistencia posee un 10% de Tolerancia");
                    Console.WriteLine("\tPresiona cualquier tecla para reiniciar el programa...");
                    Console.ReadKey();
                }
                else if (ba4 == 12)
                {
                    Console.WriteLine("\tLa resistencia posee un 20% de Tolerancia");
                    Console.WriteLine("\tPresiona cualquier tecla para reiniciar el programa...");
                    Console.ReadKey();
                }
                else if (ba4 == 0 || ba4 >= 3 && ba4 <= 9 || ba4 >= 14)
                {
                    Console.WriteLine("\tIngrese un número válido");
                    Console.WriteLine("\tPresiona cualquier tecla para reiniciar el programa...");
                    Console.ReadKey();
                }
            } while (bucle);
            Console.WriteLine("Presiona cualquier tecla para salir...");
            Console.ReadKey();
        }
    }
}
