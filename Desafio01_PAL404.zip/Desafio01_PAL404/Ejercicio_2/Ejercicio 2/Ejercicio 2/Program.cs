﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WindowHeight = 30; // alto de la ventana
            Console.WindowWidth = 75; //ancho de la ventana
            Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.White;
            Console.Clear();
            Console.Title = "Ejercicio 2 DESAFIO PRACTICO 1";
            //Declaracion de opciones.
            Console.WriteLine("Elije una figura geométrica:\n" +
            "\n1 - Esfera" +
            "\n2 - Pirámide" +
            "\n3 - Cono");    

            String r1 = "";

            r1 = Console.ReadLine();

            switch (r1) {

                case "1":
                    double R, A; // Variables para Esferas.
                    const double PI = 3.1416;            
                    System.Console.Write(" Ingrese el radio de la Esfera: "); // Datos de Entrada.
                    R = double.Parse(System.Console.ReadLine());
                    A = PI * Math.Pow(R, 2); // Proceso para el Resultado.
                    System.Console.Write(" La superficie total de la Esfera es: " + A); // Datos de Salida.
                    break;

                case "2":
                    /* (AB = B x B) (AL = )
                    /* AT = AB + AL = Superficie Total(ST). */
                    double B, A1, AB, AL, AL1, ST; // Variables para Pirámide.
                    System.Console.WriteLine(" Ingrese el lado de una de las bases de la Pirámide: "); // Datos de Entrada.
                    B = double.Parse(System.Console.ReadLine());
                    System.Console.Write(" Ingrese la altura de una de las caras de la Pirámide: "); // Datos Salida.
                    A1 = double.Parse(System.Console.ReadLine());
                    AB = B * B;
                    AL = B * A1 / 2;
                    AL1 = AL * 4;
                    ST = AB + AL1;
                    System.Console.Write(" La superficie total de la Pirámide es: " + ST + "cm²"); // Datos de Salida.
                    break;

                case "3":
                    int g, a; // Variables para Conos.
                    System.Console.Write(" Ingrese la generetriz del Cono: "); // Datos de Entrada.
                    g = int.Parse(Console.ReadLine());
                    System.Console.Write(" Ingrese la altura del Cono: "); // Datos Salida.
                    a = int.Parse(Console.ReadLine());
                    System.Console.Write(" La superficie total del Cono es: " + (Math.PI * g * (g + a)));
                    break;

                default:
                    Console.WriteLine(" No se ha seleccioando una opcion.");
                    break;
            }
            Console.ReadKey();
        }
    }
}
