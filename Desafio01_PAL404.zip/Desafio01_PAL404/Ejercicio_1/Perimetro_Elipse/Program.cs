﻿using System;

namespace Perimetro_Elipse
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WindowHeight = 25;
            Console.WindowWidth = 70;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.White;
            Console.Clear();
            Console.Title = "determinar la longitud del perimetro de un eclipse";

            //Declaracion de variables
            double a, b, perimetro;
            Console.Write("Ingresa el valor de a :");
            a = double.Parse(Console.ReadLine());
            Console.Write("Ingresa el valor de b :");
            b = double.Parse(Console.ReadLine());
            perimetro = Math.PI * (3 * (a + b) - Math.Sqrt((3 * a + b) * (a + 3 * b)));
            Console.WriteLine("el valor del perimetro es :" + Math.Round(perimetro,2) + " cm.");
            Console.ReadKey();
        }
    }
}
