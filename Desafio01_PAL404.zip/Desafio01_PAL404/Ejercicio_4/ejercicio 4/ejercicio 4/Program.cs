﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_4
{
    class Program
    {
        static void Main(string[] args)
        {
            //Programa realizado por Steven Mena
            //Dia 8 de febrero

            Console.WindowHeight = 25;
            Console.WindowWidth = 70;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();
            Console.Title = "Calcular el salario semanal de un obrero";

            //Declaracion de variables
            int horast, horasextras;
            double salariototal, pago, pagoextra;

            //Entrada de datos
            Console.WriteLine("Ingrese el pago por hora laborada");
            pago = double.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el numero de horas trabajadas en la semana");
            horast = int.Parse(Console.ReadLine());

            //proceso de datos
            if (horast <= 30)
            {
                salariototal = pago * horast;
            }
            else
            {
                horasextras = horast - 30;
                pagoextra = pago * 1.25;
                salariototal = (pago * 30) + (horasextras * pagoextra);

            }
            //salida de datos
            Console.WriteLine("El salario semanal del obrero es $" + salariototal);
            Console.ReadKey();
        }
    }
}
